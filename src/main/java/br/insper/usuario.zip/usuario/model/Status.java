package br.insper.usuario.model;
 public enum Status {
        PLANEJAMENTO,
        EXECUCAO,
     ATIVO, FINALIZADO
    }

